*_complete.bin is for flashing with FlashCatUSB or any other hardware programmer tool.
*_update.bin is for GUI flashing.