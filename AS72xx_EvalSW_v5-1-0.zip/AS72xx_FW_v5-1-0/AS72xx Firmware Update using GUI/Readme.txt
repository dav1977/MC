AS72xx Firmware Update using GUI


This folder consist of

          - FTDI Virtual COM Port Driver Setup exe file 
          - GUI for firmware update (ams_ASxx_Firmware_Update.tcl)
          - current AS72xx firmware - 56kb firmware bin file and AT-command list xlsx file


Note: - PC and Winbdws 32/64 Bit
              ActiveState TCL Run-Time Setup - TCL run time exe file for windows 32 or 64 bit (download from ActiveState TCL site) to run the Dashboard Software 



User will have to create an account on ams.com (click login -> Create Account) to request the download SW data and relevent documents 

Please read Application Notes - "ASxx_AN000622 - External Flash Program and Update" and "AS72xx_AN000623 - How to Flash AS72xx Firmware Using Firmware Update GUI" in the documentation set. Then connect the hardware based on our instructions and run the test software.
