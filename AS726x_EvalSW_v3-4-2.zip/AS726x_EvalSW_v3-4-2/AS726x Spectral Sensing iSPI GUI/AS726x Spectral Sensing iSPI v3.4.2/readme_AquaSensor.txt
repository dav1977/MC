
For using the special initial parameters for the AquaSensor to calculate the corrected values and the NTU value, please use the "init_file_AquaSensor".

1) Please remove the "init_file.txt" in the folder, that contains also the executable "AS726x_Spectral_Sensing_iSPI.exe"
2) Please copy the "init_file_AquaSensor.txt" to the same folder
3) Please rename the "init_file_AquaSensor.txt" into "init_file.txt"